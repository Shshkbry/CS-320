/** 
 * Written by Mary Sanders
 * CS 320
 * November 19, 2023
 */

package contactservice;

public class Contact {
	
	//variable declarations
	
	private final String contactID; 
	private String firstName;
	private String lastName;
	private String phoneNum;
	private String contactAddress;
	
	
	public Contact(String id, String firstN, String lastN, String phNum, String ctcAddr) {
		
		//verifying that arguments match requirements
		
		if(id == null || id.length() > 10) {
			throw new IllegalArgumentException("Invalid contactID");
		}
		
		else if(firstN == null || firstN.length() > 10) {
			throw new IllegalArgumentException("Invalid firstName");
		} 
		
		else if(lastN == null || lastN.length() > 10) {
			throw new IllegalArgumentException("Invalid lastName");
		} 
		
		else if(phNum == null || phNum.length() != 10) {
			throw new IllegalArgumentException("Invalid phoneNum");
		} 
		
		else if(ctcAddr == null || ctcAddr.length() > 30) {
			throw new IllegalArgumentException("Invalid contactAddress");
		}
		
			this.contactID = id;
			this.firstName = firstN;
			this.lastName = lastN;
			this.phoneNum = phNum;
			this.contactAddress = ctcAddr;
	}
	//mutators and accessors
	public String getContactID() {
		return this.contactID;
	}
	
	public void setContactID(String id) {
		throw new IllegalArgumentException("ContactID is fixed");
	}
	
	public String getFirstName(){
		return this.firstName;
		
	}
	
	public String getLastName() {
		return this.lastName;
	}
	
	public String getPhoneNum() {
		return this.phoneNum;
		
	}
	
	public String getContactAddress() {
		return this.contactAddress;
	}

	public void setFirstName(String firstN) {
		this.firstName = firstN;
	}
	
	public void setLastName(String lastN) {
		this.lastName = lastN;
	}
	
	public void setPhoneNumber(String phNum) {
		this.phoneNum = phNum;
	}
	
	public void setAddress(String ctcAddr) {
		this.contactAddress = ctcAddr;
	}
	//new contact instance
	
	public static void main(String args[]) {
		Contact contact = new Contact("1234567890", "Emcee","Piepents","7175550000","612 Wharf Ave");
		System.out.println(contact.getContactID());
		System.out.println(contact.getFirstName());
		System.out.println(contact.getLastName());
		System.out.println(contact.getPhoneNum());
		System.out.println(contact.getContactAddress());
	}		
}