/** 
 * Written by Mary Sanders
 * CS 320
 * November 19, 2023
 */

package contactservice;
import java.util.*;

public class ContactService {
	private ArrayList<Contact> contactList;
	public ContactService() {
		contactList = new ArrayList<>();
	}
	
	//add contact method
	public boolean addContact(Contact contact) {
		
		boolean contactFound = false;
		
		//search for existing contact
		for(Contact ctc:contactList) {
			if(ctc.equals(contact)) {
				contactFound = true;
			}
		}
		
		//add if no existing contact found	
		if(!contactFound) {
			contactList.add(contact);
			return true;
		}
		else { 
			return false;
		}
	}
	
	//delete contact from contactList	
	public boolean deleteContact(String id) {
		
		//search list for contact
		for(Contact ctc:contactList) {
			
			//if found, remove from list
			if(ctc.getContactID().equals(id)) {
				contactList.remove(ctc);
				return true;
				
			}
		}
		return false;
	}
//update existing contact
	public boolean updateContact(String id, String firstN, String lastN, String phNum, String ctcAddr) {
		
		//search contactList for contact
		for(Contact ctc:contactList) {
			
			//if found and contact input is valid
			if(ctc.getContactID().equals(id)) {
				
				if(!firstN.equals("") && !(firstN.length() > 10)) {
					ctc.setFirstName(firstN);
				}
				
				if(!lastN.equals("") && !(lastN.length() > 10)) {
					ctc.setLastName(lastN);
				}
				
				if(!phNum.equals("") && !(phNum.length() > 10)) {
					ctc.setPhoneNumber(phNum);
				}
				
				if(!ctcAddr.equals("") && !(ctcAddr.length() > 30)) {
					ctc.setAddress(ctcAddr);
				}
				return true;
			}
		}
		return false;
		
	}
}
	

