/** 
 * Written by Mary Sanders
 * CS 320
 * November 19, 2023
 */

package tests;

import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import contactservice.Contact;

public class ContactTest {
	protected String ctcIDTest, firstNTest, lastNTest, phNumTest, ctcAddrTest;
	protected String longID, longFirstN, longLastN, longPhNum, invalidPhNum, longCtcAddr;
	
	//testing values
	@BeforeEach
	void testVals() {
		ctcIDTest = "0123456789";
		firstNTest = "Emcee";
		lastNTest = "Peipants";
		phNumTest = "7175550000";
		ctcAddrTest = "612 Wharf Avenue";
		longID = "01234567890";
		longFirstN = "ABCDEFGHIJKLMNOP";
		longLastN = "ABCDEFGHIJKLMNOP";
		longPhNum = "71755500000";
		invalidPhNum = "5550000";
		longCtcAddr = "612 Wharf Avenue, Red Bank NJ, 07701"; 
	}
	
	//ContactID tests
	@Test
	void TestNullContactID() {
		assertThrows(IllegalArgumentException.class, 
				() -> {new Contact(null, firstNTest, lastNTest, phNumTest, ctcAddrTest);});
	}
	
	@Test
	void testContactIDVal() {
		assertThrows(IllegalArgumentException.class,
				() -> {new Contact(null, firstNTest, lastNTest, phNumTest, ctcAddrTest);});
	}
	
	@Test
	void testIDLength() {
		assertThrows(IllegalArgumentException.class, 
				() -> {new Contact(longID, firstNTest, lastNTest, phNumTest, ctcAddrTest);});
	}
	
	@Test
	void testIDSttr() {
		Contact testContact = new Contact(ctcIDTest, firstNTest, lastNTest, phNumTest, ctcAddrTest);
		assertThrows(IllegalArgumentException.class, 
				() -> {testContact.setContactID("newID");});
	}
	
	//FirstName tests
	@Test
	void testFirstNVal() {
		assertThrows(IllegalArgumentException.class, 
				() -> {new Contact(ctcIDTest, null, lastNTest, phNumTest, ctcAddrTest);});
	}

	@Test
	void testFirstNLength() {
		assertThrows(IllegalArgumentException.class, 
				() -> {new Contact(ctcIDTest, longFirstN, lastNTest, phNumTest, ctcAddrTest);});
	}
	
	//LastName tests
	@Test
	void testLastNVal() {
		assertThrows(IllegalArgumentException.class, 
				() -> {new Contact(ctcIDTest, firstNTest, null, phNumTest, ctcAddrTest);});
	}

	@Test
	void testLastNLength() {
		assertThrows(IllegalArgumentException.class, 
				() -> {new Contact(ctcIDTest, firstNTest, longLastN, phNumTest, ctcAddrTest);});
	}
	
	//PhoneNumber tests
	@Test
	void testPhNumVal() {
		assertThrows(IllegalArgumentException.class, 
				() -> {new Contact(ctcIDTest, firstNTest, lastNTest, null, ctcAddrTest);});
	}
	
	@Test
	void testPhNumLength() {
		assertThrows(IllegalArgumentException.class, 
				() -> {new Contact(ctcIDTest, firstNTest, lastNTest, longPhNum, ctcAddrTest);});
	}

	//Address tests
	@Test
	void testAddrVal() {
		assertThrows(IllegalArgumentException.class, 
				() -> {new Contact(ctcIDTest, firstNTest, lastNTest, phNumTest, null);});
	}
		
	@Test
	void testAddrLength() {
		assertThrows(IllegalArgumentException.class, 
				() -> {new Contact(ctcIDTest, firstNTest, lastNTest, phNumTest, longCtcAddr);});
	}
	
}